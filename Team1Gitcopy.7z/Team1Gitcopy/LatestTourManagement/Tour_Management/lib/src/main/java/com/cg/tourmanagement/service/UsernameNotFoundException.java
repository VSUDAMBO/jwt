package com.cg.tourmanagement.service;

public class UsernameNotFoundException extends Exception {

}
