package com.cg.tourmanagement.exception;

@SuppressWarnings("serial")
public class StaffUserIdAlreadyExistsException extends RuntimeException {

}
