package com.cg.tourmanagement.exception;

@SuppressWarnings("serial")
public class PaymentUnsccuessfullException extends  RuntimeException{

}
