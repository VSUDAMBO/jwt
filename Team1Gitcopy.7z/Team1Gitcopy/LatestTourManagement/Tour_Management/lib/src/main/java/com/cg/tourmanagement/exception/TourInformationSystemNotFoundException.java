package com.cg.tourmanagement.exception;

@SuppressWarnings("serial")
public class TourInformationSystemNotFoundException extends RuntimeException {

}
