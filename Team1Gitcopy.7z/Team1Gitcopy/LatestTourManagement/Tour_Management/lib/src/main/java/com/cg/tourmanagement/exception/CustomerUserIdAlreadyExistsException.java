package com.cg.tourmanagement.exception;

@SuppressWarnings("serial")
public class CustomerUserIdAlreadyExistsException extends RuntimeException{

}
