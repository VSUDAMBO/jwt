package com.cg.tourmanagement.service;

import java.util.List;

import com.cg.tourmanagement.entities.TourInfo;

public interface TourInfoService {
	List<TourInfo> viewAllReservedTourPackages();
}
