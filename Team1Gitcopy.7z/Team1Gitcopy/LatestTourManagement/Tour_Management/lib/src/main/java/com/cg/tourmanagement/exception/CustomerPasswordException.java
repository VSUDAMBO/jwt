package com.cg.tourmanagement.exception;

@SuppressWarnings("serial")
public class CustomerPasswordException  extends RuntimeException {

}
