package com.cg.tourmanagement.exception;

@SuppressWarnings("serial")
public class StaffPasswordException extends RuntimeException {

}
